package xinxiang.service;

import xinxiang.domain.LoginUser;
import xinxiang.domain.PageBean;
import xinxiang.domain.User;

import java.util.List;
import java.util.Map;

/**
 * 用户管理的业务接口
 */
public interface UserService {

    /**
     * 查询所有用户信息
     * @return
     */
    public List<User> findAll();

    /**
     * 判断登录输入
     * @return
     */
    public LoginUser checkLogin(LoginUser loginUser);

    /**
     * 添加联系人
     */
    public boolean addLinkMan(User addUser);

    /**
     * 删除联系人
     * @param id
     */
    public void delLinkMan(int id);

    /**
     * 修改联系人，先获取
     * @param id
     * @return
     */
    public User upListLinkman(int id);

    /**
     * 修改联系人
     * @param user
     */
    public void updateLinkman(User user);

    /**
     * 删除选中
     * @param uids
     */
    public void delSelectServlet(String[] uids);

    /**
     * 分页和条件查询
     * @param _currentPage
     * @param _rows
     * @param condition
     * @return
     */
    PageBean<User> findByPage(String _currentPage, String _rows, Map<String, String[]> condition);
}
