package xinxiang.service.impl;

import xinxiang.dao.UserDao;
import xinxiang.dao.impl.UserDaoImpl;
import xinxiang.domain.LoginUser;
import xinxiang.domain.PageBean;
import xinxiang.domain.User;
import xinxiang.service.UserService;

import java.util.List;
import java.util.Map;

public class UserServiceImpl implements UserService {

    private UserDao dao = new UserDaoImpl();

    @Override
    public List<User> findAll() {
        //调用dao完成查询
        return dao.findAll();
    }

    @Override
    public LoginUser checkLogin(LoginUser loginUser) {

        return dao.checkLogin(loginUser);

    }

    @Override
    public boolean addLinkMan(User addUser) {

        return dao.addLinkMan(addUser);
    }

    @Override
    public void delLinkMan(int id) {
        dao.delLinkMan(id);
    }

    @Override
    public User upListLinkman(int id) {
        return dao.upListLinkman(id);
    }

    @Override
    public void updateLinkman(User user) {
        dao.updateLinkman(user);
    }

    @Override
    public void delSelectServlet(String[] str) {
        if (str != null && str.length > 0){
            for (String id: str) {
                dao.delLinkMan(Integer.parseInt(id));
            }
        }

    }

    @Override
    public PageBean<User> findByPage(String _currentPage, String _rows, Map<String, String[]> condition) {
        int currentPage = Integer.parseInt(_currentPage);
        int rows = Integer.parseInt(_rows);
        if (currentPage <= 0)
            currentPage = 1;
        //创建一个空的PageBean对象
        PageBean<User> pb = new PageBean<User>();

        //调用dao查询总记录数
        int totalCount = dao.findTotalCount(condition);
        pb.setTotalCount(totalCount);
        //计算总页码
        int totalPage = (totalCount % rows) == 0 ? (totalCount / rows) : (totalCount / rows) + 1;
        pb.setTotalPage(totalPage);
        if (currentPage >= totalPage)
            currentPage = totalPage;

        //设置参数
        pb.setCurrentPage(currentPage);
        pb.setRows(rows);

        //调用dao查询List集合
        //计算开始的记录索引
        int start = (currentPage - 1) * rows;
        List<User> list = dao.findByPage(start,rows,condition);
        pb.setList(list);



        return pb;
    }

}
