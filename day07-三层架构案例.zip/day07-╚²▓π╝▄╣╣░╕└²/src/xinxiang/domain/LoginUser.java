package xinxiang.domain;

public class LoginUser {

    private String username;
    private String password;
    private String verifycode;

    public LoginUser(String username, String password, String verifycode) {
        this.username = username;
        this.password = password;
        this.verifycode = verifycode;
    }

    public LoginUser() {
    }

    public String getVerifycode() {
        return verifycode;
    }

    public void setVerifycode(String verifycode) {
        this.verifycode = verifycode;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "LoginUser{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", verifycode='" + verifycode + '\'' +
                '}';
    }
}
