package xinxiang.test;

import org.junit.Test;
import xinxiang.dao.UserDao;
import xinxiang.dao.impl.UserDaoImpl;
import xinxiang.domain.LoginUser;
import xinxiang.domain.User;
import xinxiang.service.UserService;
import xinxiang.service.impl.UserServiceImpl;

public class UserDaoImplTest {
    @Test
    public void testLogin(){
        LoginUser login = new LoginUser();
        login.setUsername("张三");
        login.setPassword("zhangsan");

        UserServiceImpl dao = new UserServiceImpl();

        LoginUser user = dao.checkLogin(login);
        System.out.println(user);
    }

    @Test
    public void testAdd(){
        User addUser = new User("刘佳乐","MM",20,"广东",
                "2541548683","25415@qq.com");
        UserDaoImpl dao = new UserDaoImpl();
        boolean b = dao.addLinkMan(addUser);

        System.out.println(b);


    }

    @Test
    public void testUplist(){
        UserDaoImpl dao = new UserDaoImpl();
        User user = dao.upListLinkman(1);
        System.out.println(user.toString());
    }

    @Test
    public void testUpLinkman(){
        UserDaoImpl dao = new UserDaoImpl();
        User user = new User(30,"刘佳乐","男",20,"广东",
                "2541548683","25415@qq.com");

        dao.updateLinkman(user);


    }

    @Test
    public void testCheckIfNull(){
        User user = new User(30,"dsada","女",21,"广东",
                "1","25415@qq.com");
        /*System.out.println(user.checkIfNull(user));
        System.out.println(user.toString());
        System.out.println(user.getId());
        System.out.println(user.getName().length() > 0);
        System.out.println(user.getGender().length() > 0);
        System.out.println(user.getAddress().length() > 0);
        System.out.println(user.getQq().length() > 0);
        System.out.println(user.getEmail().length() > 0);
        System.out.println(user.getAge());*/

        if (user.getId() == 0 || user.getName().length() == 0 || user.getGender().length() == 0 || user.getAge() == 0 ||
                user.getAddress().length() == 0 || user.getQq().length() == 0 || user.getEmail().length() == 0){
            System.out.println(user.toString());
        }
    }

}
