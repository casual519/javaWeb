package xinxiang.dao;

import xinxiang.domain.LoginUser;
import xinxiang.domain.User;

import java.util.List;
import java.util.Map;

/**
 * 用户操作的接口
 */
public interface UserDao {

    public List<User> findAll();

    public LoginUser checkLogin(LoginUser loginUser);

    public boolean addLinkMan(User addUser);

    public void delLinkMan(int id);

    public User upListLinkman(int id);

    public void updateLinkman(User user);

    /**
     * 查询总记录数
     * @return
     * @param condition
     */
    public int findTotalCount(Map<String, String[]> condition);

    /**
     * 分页查询，每页的记录
     * @param start
     * @param rows
     * @param condition
     * @return
     */
    public List<User> findByPage(int start, int rows, Map<String, String[]> condition);
}
