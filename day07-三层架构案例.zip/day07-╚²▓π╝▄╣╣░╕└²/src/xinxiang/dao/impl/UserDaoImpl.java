package xinxiang.dao.impl;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import xinxiang.dao.UserDao;
import xinxiang.domain.LoginUser;
import xinxiang.domain.User;
import xinxiang.util.JdbcUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class UserDaoImpl implements UserDao {

    private JdbcTemplate template = new JdbcTemplate(JdbcUtils.getDataSource());

    @Override
    public List<User> findAll() {
        //使用JDBC操作数据库
        //1.定义sql
        String sql = "select * from linkman";
        List<User> linkmen = template.query(sql, new BeanPropertyRowMapper<User>(User.class));

        return linkmen;
    }

    @Override
    public LoginUser checkLogin(LoginUser loginUser) {

        try {
            //1.编写sql
            String sql = "select * from user where username = ? and password = ?";
            //2.调用query方法
            return template.queryForObject(sql, new BeanPropertyRowMapper<LoginUser>(LoginUser.class),
                    loginUser.getUsername(), loginUser.getPassword());
        } catch (DataAccessException e) {
            //e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean addLinkMan(User addUser) {
        //编写sql
        String sql = "insert into linkman values(null,?,?,?,?,?,?)";
        int count = 0;
        try {
            count = template.update(sql, addUser.getName(), addUser.getGender(), addUser.getAge(),
                    addUser.getAddress(), addUser.getQq(), addUser.getEmail());
        } catch (DataAccessException e) {
            //e.printStackTrace();
        }
        if (count != 0)
            return true;
        else
            return false;
    }

    @Override
    public void delLinkMan(int id) {
        //编写sql
        String sql = "delete from linkman where id = ?";
        template.update(sql,id);
    }

    @Override
    public User upListLinkman(int id) {
        //查询此id的数据
        String sql = "select * from linkman where id = ?";
        return template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class), id);
    }

    @Override
    public void updateLinkman(User user) {
        //写sql
        String sql = "update linkman set name = ? , gender = ? , age = ? , " +
                "address = ? , QQ = ? , email = ? where id = ?";

        template.update(sql, user.getName(), user.getGender(),
                user.getAge(), user.getAddress(), user.getQq(), user.getEmail(), user.getId());
    }

    @Override
    public int findTotalCount(Map<String, String[]> condition) {
        //定义模板sql
        String sql = " select count(*) from linkman where 1 = 1 ";
        StringBuilder sb = new StringBuilder(sql);
        //遍历map
        Set<String> keySet = condition.keySet();
        //定义参数的集合
        List<Object> params = new ArrayList<Object>();
        for (String key : keySet) {

            //排除分页
            if ("currentPage".equals(key) || "rows".equals(key))
                continue;
            //获取value
            String value = condition.get(key)[0];
            //判断是否有值
            if (value != null && !"".equals(value)){
                //有值
                sb.append(" and " + key + " like ? ");
                params.add("%"+value+"%");//?有值的条件
            }
        }


        return template.queryForObject(sb.toString(), Integer.class,params.toArray());//返回一个Integer类型，自动拆箱
    }

    @Override
    public List<User> findByPage(int start, int rows, Map<String, String[]> condition) {
        //定义模板sql
        String sql = " select * from linkman where 1 = 1 ";
        StringBuilder sb = new StringBuilder(sql);
        //遍历map
        Set<String> keySet = condition.keySet();
        //定义参数的集合
        List<Object> params = new ArrayList<Object>();
        for (String key : keySet) {

            //排除分页
            if ("currentPage".equals(key) || "rows".equals(key))
                continue;
            //获取value
            String value = condition.get(key)[0];
            //判断是否有值
            if (value != null && !"".equals(value)){
                //有值
                sb.append(" and " + key + " like ? ");
                params.add("%"+value+"%");//?有值的条件
            }
        }
        //添加分页查询
        sb.append(" limit ? , ? ");
        //添加分页查询参数值
        params.add(start);
        params.add(rows);
        System.out.println(sb.toString());
        System.out.println(params);


        return template.query(sb.toString(),new BeanPropertyRowMapper<User>(User.class),params.toArray());//BeanPropertyRowMapper,查询的是结果集，如果只有一个结果，返回一个对象，如果有多个，返回一个list集合
    }
}
