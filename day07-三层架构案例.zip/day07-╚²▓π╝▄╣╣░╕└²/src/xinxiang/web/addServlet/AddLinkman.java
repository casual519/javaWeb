package xinxiang.web.addServlet;

import org.apache.commons.beanutils.BeanUtils;
import xinxiang.domain.User;
import xinxiang.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/addLinkman")
public class AddLinkman extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置request编码
        request.setCharacterEncoding("utf-8");
        //接受数据
        User addUser = new User();
        Map<String, String[]> addMap = request.getParameterMap();
        //使用BeanUtils封装对象
        try {
            BeanUtils.populate(addUser, addMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        //调用service完成添加
        UserServiceImpl service = new UserServiceImpl();
        boolean b = service.addLinkMan(addUser);
        if (b)
            //无数据交互，重定向
            response.sendRedirect(request.getContextPath()+"/userListServlet");
        else
            //无数具有交互，重定向
            response.sendRedirect(request.getContextPath()+"/addlinkman.jsp");

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
