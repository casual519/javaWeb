package xinxiang.web.loginServlet;

import org.apache.commons.beanutils.BeanUtils;
import xinxiang.domain.LoginUser;
import xinxiang.service.UserService;
import xinxiang.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置request编码
        request.setCharacterEncoding("utf-8");
        //获取参数
        UserService service = new UserServiceImpl();
        Map<String, String[]> parameterMap = request.getParameterMap();
        LoginUser loginUser = new LoginUser();

        //使用BeanUtils封装对象
        try {
            BeanUtils.populate(loginUser, parameterMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        //获取生成的验证码
        HttpSession session = request.getSession();

        String checkCode_session = null;
        try {
            checkCode_session = session.getAttribute("checkCode_session").toString();
        } catch (Exception e) {
            //e.printStackTrace();
            request.getRequestDispatcher("/login.jsp").forward(request,response);
        }
        //删除验证码，防止返回后，验证码二次使用
        session.removeAttribute("checkCode_session");
        //判断验证码是否正确
        if (checkCode_session != null && checkCode_session.equalsIgnoreCase(loginUser.getVerifycode())){
            //忽略大小写比较
            //验证码正确
            //判断用户名和密码是否一致
            LoginUser user = service.checkLogin(loginUser);
            if (user != null) {
                //登录成功
                session.setAttribute("loginUser",loginUser);
                //重定向
                response.sendRedirect(request.getContextPath()+"/index.jsp");
            } else {
                //登录失败
                //存储信息到request
                request.setAttribute("login_error","用户名或密码错误");
                //转发到login.jsp
                request.getRequestDispatcher("/login.jsp").forward(request,response);
            }
        }else{
            //验证码错误
            //存储信息到request
            request.setAttribute("checkCode_error","验证码错误");
            //System.out.println(loginUser.getCheckCode());
            //转发到login.jsp
            request.getRequestDispatcher("/login.jsp").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
