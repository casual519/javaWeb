package xinxiang.web.operation;

import org.apache.commons.beanutils.BeanUtils;
import xinxiang.domain.User;
import xinxiang.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

@WebServlet("/updateServlet_2")
public class UpdateServlet_2 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置request编码
        request.setCharacterEncoding("utf-8");
        //接受数据
        User addUpUser = new User();
        Map<String, String[]> addUpMap = request.getParameterMap();
        //使用BeanUtils封装对象
        try {
            BeanUtils.populate(addUpUser, addUpMap);
        } catch (IllegalAccessException e) {
            //e.printStackTrace();
        } catch (InvocationTargetException e) {
            //e.printStackTrace();
        }
        //调用service完成添加
        UserServiceImpl service = new UserServiceImpl();
        if (addUpUser.checkIfNull(addUpUser)){
            service.updateLinkman(addUpUser);
            response.sendRedirect(request.getContextPath()+"/userListServlet");

        }else {
            request.getRequestDispatcher("/updateServlet").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
